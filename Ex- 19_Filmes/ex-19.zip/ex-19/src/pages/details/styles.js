import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  titulo:{
    marginTop: 5,
    fontSize: 18,
    textAlign: 'center'
  },
  texto:{
    fontSize: 16,
  },
})

export {styles};