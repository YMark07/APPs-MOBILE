import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
   container:{
    flex: 1,
    marginTop: 60,
    alignItems: 'center'
  },
  titulo:{
    marginTop: 5,
    fontSize: 18,
    textAlign: 'center'
  },
  foto:{
     width: 250, 
     height: 100, 
  },
})

export {styles};