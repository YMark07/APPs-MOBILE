import React from 'react';
import { View, Text } from 'react-native';


export default function Experiencia() {
 return (
   <View>
     <Text>Experiencia</Text>
   </View>
  );
}
