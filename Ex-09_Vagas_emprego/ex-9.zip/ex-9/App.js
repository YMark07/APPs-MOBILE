import React, { Component } from 'react';
import { View, ScrollView,Image, Text } from 'react-native';
import {styles} from './styles';

class App extends Component{
  
  render(){
   
    return(
      <View style={styles.container}>
      <Text style={styles.titulo}> Vagas: </Text>
        <ScrollView horizontal={false}>
          
          <View style={styles.box}>

        <Text style={styles.titulo2}> 
        Desenvolvedor de Backend
        </Text>
        <Text style={styles.texto}> 
        Salário:$6000,00
        </Text>
        <Text style={styles.texto}> 
        Descrição:remoto, nescessita de conhecimento sobre php,javascript.
        </Text>
        <Text style={styles.texto}> 
        Contato:emprego1@gmail.com
        </Text>
          </View>
            
         <View style={styles.box}>

        <Text style={styles.titulo2}> 
        Engenheiro de dados
        </Text>
        <Text style={styles.texto}> 
        Salário:$3500,00
        </Text>
        <Text style={styles.texto}> 
        Descrição:Nescessita de experiência prévia
        </Text>
        <Text style={styles.texto}> 
        Contato:emprego2@gmail.com
        </Text>
          </View>

          <View style={styles.box}>

        <Text style={styles.titulo2}> 
        Engenheiro de requisitos
        </Text>
        <Text style={styles.texto}> 
        Salário:$3800,00
        </Text>
        <Text style={styles.texto}> 
        Descrição:Nescessita de experiência prévia
        </Text>
        <Text style={styles.texto}> 
        Contato:emprego3@gmail.com
        </Text>
          </View>

          <View style={styles.box}>

        <Text style={styles.titulo2}> 
        Desenvolvedor de Backend
        </Text>
        <Text style={styles.texto}> 
        Salário:$3200,00
        </Text>
        <Text style={styles.texto}> 
        Descrição:Nescessita de experiência prévia
        </Text>
        <Text style={styles.texto}> 
        Contato:emprego4@gmail.com
        </Text>
          </View>

          <View style={styles.box}>
        <Text style={styles.titulo2}> 
        Analista de sistemas
        </Text>
        <Text style={styles.texto}> 
        Salário:$3300,00
        </Text>
        <Text style={styles.texto}> 
        Descrição:Nescessita de experiência prévia
        </Text>
        <Text style={styles.texto}> 
        Contato:emprego5@gmail.com
        </Text>
          </View> 
        </ScrollView>

        

      </View>
    )
  }
}


export default App;
