import React, { Component } from 'react';
import { View, Text,Image, TextInput, Pressable} from 'react-native';
import {styles} from './styles';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      random: Math.floor(Math.random() * 10),
      numero:0,
      resultado:'',
    };
    
    this.calcular = this.calcular.bind(this);
  }


  calcular(){
    if (this.state.numero === ''){
      alert('Digite o numero!') 
      return;
    }   

      if(parseFloat(this.state.numero)==this.state.random){
      this.setState({resultado: 'Você acertou o numero, parabens!!!'}); 
      }
      else{
      this.setState({resultado: 'Você errou o numero, Tente de novo!!!!'});
      }
    
  }


  render(){

    let img = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBMSEBEWFRMVFxkSFRcQFg8WEBURGBUXGRUZFRUYHSgsGBomGxUYIjIhJSkrLi4uFyIzODMsNygtLi0BCgoKDg0OGxAQGisiHyIvNy0rNTItLTI1MDIvLS01Ni8tLTAwLS0tNy8tLTUtNy0tNS0rLS0rLS0rMC0tMistLf/AABEIAOUA3AMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABQIDBAYHAQj/xABEEAACAQIEAgcEBgYIBwAAAAAAAQIDEQQSITEFQQYTIlFhcZEHMoHBQlKSobHRFlNiwtLwFBUjJGNzo7NDZHKCssPh/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAIEBQMBBv/EACsRAQEAAgECBAQGAwAAAAAAAAABAgMRBCESEzFBUWFxoQUUFSIy0SNCkf/aAAwDAQACEQMRAD8A7iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGDxriMcNQnWl9FaLnKT0ivi2hbw9ktvEU8T43hsNZV6qi3su1KbXflim7eNinCcfwlVqNPEU3J7RclGb8oys2cmdCvipVa7WeV803z1vZRXNJLbyMStScXaUWnvr3NafBoq/mO7SnQ48d73d2uDWugvG3iaGWbvUpWTb3lB+5J+OjT8r8zZSzjZZzGdnhcMrjQAHqIAAAAAAAAAAAAAAAAAAAAAAGLi8dCm0pXu9dFyPMspjOa9xxuV4jKBgw4rRf0reaZY4h0hwtDJ1tVLPezSk1pa97LTdbkZswvpYn5Wznjw3/iVNa6ZQU+pptJq8p2ezacYq656VH9xN4LiFGsr0asJr9iUXbztsQ/Sii3Uw876RdSL/AO6MbL7vwIbr/jtifTzjbJUHgcG8PQy04qc/ealLLmk/2rO2mnw5HlaVGcISxNOMHJ5FGq4NqcrrKpLe9m18OZnTpxla6TyvMr8pWauvGzfqe4TCOrOMX7sr54tRd4Wsk3y0+9mXj+68e7Uyy4ltS3RvgdLCxzU8ylOKzZne6u3HTwu18SaPEemxjOJwxs8rleaAAkiAAAAAAAAAAAAAAAAAAAAABC8eh2oy8GvTX5k0Y2Pw3WQa57rzOW7Dx4WR105+DOWtTxCs1NctJeMH+T19TWum8u1RXcpv1cfyNrnHdNeDT+ZB9N+Fzq01ioOCjTjGnUjqpZnN9pcnfMvQzNWPN+jc0ZzHZjz7tJst+a270bV0e445rqMRVk+dKVSV2tuzmfik1f8AI1Y8aOtnM4ae3VjsnFdIxHFI0Msa8kozbSlZtXVrtpJuO+6Np4RhoRgpxkp50mpR1i4vVZXzXicRnVnJKLm3GOyk20vLu2J7ot0nrYSSgl1lKTt1d9VJvem+Tu9tn4bk9PhxvOTM6roM7r/Ze/v83YAWMPioVPdd/DmvgXy/LLOY+fss7UAB68AAAAAAAAAAAAAAAAAAAAAAAAR3E+H5+1D3uf7S/M1bjNKc8NWpxWsorTm3GSlbz7LXxN6IbpFThTpSru6yWcrK91dLbwuVN+j/AHx9V3pd9mUxvfv2cYBNcf4d/axqUFnhW1jk1WfmtO/f17iqp0YnClnqVEna+VKNl5zlKK/nmVvFH03n4cS2+qCuT3RfhNSVaFWVOXVpOqpW7LtLIrPwl+BBWt/8Ouez+V+H0fB1F/qz/M64YePmK/4hvy06uZPW8MWMmndOz8NyVwXFntU+1+a+ZkYzhcJXlHsvfT3fTkQOFpylli9ZPT4v5fkcrjs0ZdmR4te/G8+zbkz0ppxsklyVvQqNRlgAAAAAAAAAAAAAAAAAAAAAAABD9Lo3wOJ/ypP0V/kS9zC43S6zDV4LeVKpFebg0jy+ieq8Zy/NyHgnGZYbMrOUWtI3slPk9tPEsYvitaq5OU3ryjdKK10j3aNp999bmFT1tZrXv22KnFfWX3/kZnElfaTTjcvFx3UnVfZrO+BS+rUmvwl+8cscNL3T9bnRPZtjIwwlXM9FWa013pwfyZ305SZc1Q/FsLdHHzjb+KVctKXisvroYPA8NvUflH5v5epTxDEqs4Qg9G9W01rsvmTFGmoxUVslYnJNm3xe0YFt16vD71WAC0rAAAAAAAAAAAAAAAABROWtlueVG7pIsVb5rRfatvySAv8Aa8PvCk09TBfV83KXe1sVt2y9puDej5p+IGeeNlptxa1umUuzu3sgNf6cQTp0pb2k4+sb/umqUciknKGZc1fLf4rY3PpMoPDNypuyalpve9lttuahgaNVuMoNR1TUm9nffRPY7YXs2+hznkcVq3FOm9HD1J0JUakpwkrzi4WacU7JOW2qexVR6aRkpVI8PxTpwhCc7R7KhLsQm5ZtpSTtbTR8kzVOnvDpwx87pWqZMsk3lbyRj8NjYcJVV4SqzWalQox7MXlnOFDGUXCNksuX+kQd7KNk+ZG5VS29ZtmdkvvVWK6eUqDnTrYTEQqRtdVFCE4aXeaDlzTT15eZt9LFKDjKKd7Wld3u73dtNFolY5X0owyqY6nTjUzqajDrEpJTzVZyulJJ6RnGOq+j3WZ1rH1qdOUYyjneRWb1tFXSjd81b7z2funFWek6jPZb4+7N6P1HVxdK/wBFN+kH8ze0aP0WjGeIvTjltTd77ayitPhc3Kd4u6923je5DKSdoq9fednHwi+CypyeqWnieOs1utfxIqS+UuSKLz7l6lpSvGTa1T9NgMoFiNbTRX72Xou4HoAAAAAAAAAAtP315Mx3fNVS3tp6GTNO91qWpwbaklZr70B7hZxyKzWi18+ZjadXPucuz6l6VGLd3DXweh7Km3a60W0VsBXU+jf+dClLsz/nkVu8mrq1j2UGneL9dgIzjlSMsJVX7Dl9ntfI0adCEIRdWcknqlG+XXXuOlSUmmrLXRnF/ariJUeIOKinmo053d/2o/uHfTjc74Ytaeq8rG48cpzi3DsLWhCc6Km3OGRyveNm7XvvpdFjifCcL1kE6GiWaWWTWbtPbudl4nM8VjalSMVJRvGSndZldp93IxeIynWlmdl2cujfe33eJZnS17+cw55uH3dV4rwTCXpv+jx6xO8JL6Nmnt33y+hm1eI20nTWiSalve2r1XN3ZyLGYurUlCSSi4XtZ33t3rwLsuM1lF5qUZNLe9vmPytSx67HH0w+7vHRvDxWapFWzZFbzu9uT2NhxkkpO/1fmyjh9BujSv8AUha3LsoypRk1Zpd3wKFvNVtuzzMrksY16Ru7K336WK5bUr96vfyK4RklbRrxEqTlq35W5Hjms1Gusd2+Vt+7kVU8uSd9udt9kXu34eZQqTs1prqwKHbIsnu31ve+5lQ2LKpNXStZ73LsFZAVAAAAAAAAAAAAAAAAAAAcZ9uFG2Lw8/rUXH7FRv8A9h2Y5T7dcPpgqnc61P7XVSX/AIMsdLeNseX0coNk6N9B8bxCjKth1TUIyyJ1pTjna97JaLvZ6a21uuTIXhOGhWr0qdSoqUJzjGVSW0It6v5a6a62V2fQfDuI4ejiocMw8UuqoOrLLtTipU4wi++Us7k+el37xf6jdlh2x9UZHBOP8BxGBqKliYKMnHPHLKMk43aumvFPciMS7Ql/0v8AA6X7b1/fMP8A5L/3Jfmc3qQzJx70166HXTnc8JlSvqvDwtCK7kl6IuAGGmAAAAAAAAAAAAAAAAAAAAAAAAAAAc69t9C+CoTX0MQr+UqVRfjY6KaX7X6ObhVR/UnSl/qRi/ukzrovGzH6vK4KdK9iEXLF4mbu2qUY3d2+1PTV+EPuObG6+zPpThuGyxEsQqj61U1Hq4qXuOo3e7VveRq9RLddkndGJX25R/vOFffSmvSa/M53gY3q013zgvWSRtntL6UYfiNTDyw6mlTjOMusiovtODVrN391mscHjfE4dd9akvWrFHmmXHVJS+r6iABjJgAAAAAAAAAAAAAAAAAAAAAAAAAAGt+0Wjn4Xi13U8/2JKf7pshGdJ8P1uCxVP69CrBebpySJYXjKUfMoPE7npvOYSHRyN8bhF/zND/egR5MdDYZuI4Nf49N+k0/kRz/AI0fSoAMF0AAAAAAAAAAAAAAAAAAAAAAAAAAAKakFJNPZpp+TKgB8oxpOCyy3j2X5rR/gemZx+Cp4vEwemWvVj8FVlb7rGDnXevVG/LzOXNUT3QKN+J4Nf4qfom/ka/nXevVGyezdp8Wwauvfm/SjUfyI7f4X6Uj6LABhOgAAAAAAAAAAAAAAAAAAAAAAAAAABE9JsNUq0MtOOaWZOyaWiv3slgey8JYZ3DKZT2c8/R/FfqH60v4h+j2K/UP1pfxHQxYn5lXv1HZ8J9/7c8/R7FfqH60v4guj+K/Uv1pfxHQ7Hlh5lP1HZ8J9/7RvRzDzpYeMKkcsk5XTae8m1sSZ4ekLeVHPLxZXK+4ADxEAAAAAAAAAAAAAAAAAAAAxv6wpdb1OddZvl57X9ba2AyQY2Hx9KpfJNO1lzV73s4395Ozs1o7M8r8QpQaUppX15tJXt2mtI66a7vQDKBaeJhlzZllte91ta/4amPW4rQg0pVErpS2lls81rytZN5Jab6MDNBaniYK15pZmktVq37tvOzK1UWmq121Wvl3gVAoVaOnaWu2q18ipyS3dvMD0FmriqcIylKaSinJu60UU3L0szF/rrD/AKxeSU73uk42t7yurx3V9UBIAwFxnDXaVVOzS0u1rfW6Xu3jJZtlleugXGKGvaay3cs0KqyqMVJuV49lWa33uBngt0K0akVKDun5rZ2aaezTVrPaxcAAAAAAAAAAAAAAAAAEbHhMVW63PLfNkuurz667eLfm/gABjVOj0ZRhF1qmWm49WuxaKg7xWi15K73S+JQujFFWUZSilb3VSTtGFODUZZbxUlTWZLR3dz0AUx6LUk2+sld98aLVs8pvRxdnmm+1ulZKxcpdGcPGLi1m7Cpxc1GUoRvUeja3/tZK71s/MAC3V6LUZOXbmlLNourVsyipWeXa0El3alyp0dhKKg5ysus+jS/4s1Odrx7PaWjWqXqAB7Do1RTTbbknmvlprXrOs0tHRXb2/HUy+IcMjWjZyku1n1tNXcJQay1E1a0npa19bHoAiP0Xpuc4upLK4p7UrrNnWksui8Fo9U9NFkLo3GzXWyta0NKa6tZlJqkkuwm1y1tZXtFWABQ6M06b7E5KN4txtTcZKDk4qel52zaXb92PcXMX0ep1bZpO6U1dKlnfWObl23G6V5vs3s9mrAASHD8HGjTjTi7qN7bK15N2SWiir2SWySRkgAAAAAAAAAf/2Q==';
    return(
      <View>

      <Text style={styles.titulo}>Jogo N° aleatorio</Text>
      <Image 
      source={{uri:img}}
      style={styles.img}
      />
      <Text style={styles.texto}>Pense em um numero de 0 a 10</Text>
      <TextInput
      style={styles.input}
      keyboardType='numeric'
      onChangeText={ (texto) => this.setState({numero: texto})}
      />
      

      <Pressable style={styles.pressable}  onPress={this.calcular}>
    <Text style={styles.texto}> Palpite </Text>
    </Pressable>

    <Text style={styles.resultado}> {this.state.resultado} </Text>
      </View>
    );
  }
}



export default App;
