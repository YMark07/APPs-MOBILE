import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { StatusBar, StyleSheet, Switch, Text, View } from 'react-native';

export default function App() {
  const [dia, setDia] = useState(false);
  const [pequeno, setPequeno] = useState(false);

  useEffect(() => {
    getData();
  }, []);

  useEffect(() => {
    setData();
  }, [dia, pequeno]);

  async function setData() {
    await AsyncStorage.setItem('dia', String(dia));
    await AsyncStorage.setItem('pequeno', String(pequeno));
  }

  async function getData() {
    const dia = await AsyncStorage.getItem('dia');
    const pequeno = await AsyncStorage.getItem('pequeno');

    setDia(dia === 'true' && true);
    setPequeno(pequeno === 'true' && true);
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="default" />

      <View style={styles.header}>
        <Text style={styles.headerText}>Frases</Text>
      </View>

      <View style={styles.top}>
        <View style={styles.topSide}>
          <Text style={styles.topText}>Dia</Text>
          <Switch style={styles.switch}
            value={dia} onValueChange={(valor) => setDia(valor)} />
        </View>
        <View style={styles.topSide}>
          <Text style={styles.topText}>Pequeno</Text>
          <Switch style={styles.switch}
            value={pequeno} onValueChange={(valor) => setPequeno(valor)} />
        </View>
      </View>

      <View style={[styles.box, dia && styles["bg-light"]]}>
        <Text style={[styles.boxText, dia && styles["text-dark"], pequeno && styles.small]}>
        Valorize as pequenas conquistas!
        </Text>
        <Text style={[styles.boxText, dia && styles["text-dark"], pequeno && styles.small]}>
        Você nunca será velho demais para sonhar um novo sonho.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 48
  },
  header: {},
  headerText: {
    fontSize: 48,
    borderBottomColor: "black",
    borderBottomWidth: 2,
    textAlign: "center",
    paddingBottom: 16,
    color: "#000"
  },
  top: {
    flexDirection: "row",
    gap: 32,
    width: "100%",
    justifyContent: "space-around",
    paddingVertical: 16
  },
  topSide: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16
  },
  topText: {
    fontSize: 24
  },
  switch: {
    transform: [{ scale: 1.5 }]
  },
  "bg-light": {
    backgroundColor: "#fff"
  },
  "text-dark": {
    color: "#000"
  },
  box: {
    padding: 16,
    borderColor: "#000",
    borderWidth: 1,
    backgroundColor: "#000",
    flex: 1
  },
  boxText: {
    color: "#fff",
    fontSize: 22,
  },
  small: {
    fontSize: 12
  }
});
