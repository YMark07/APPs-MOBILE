import React, { Component } from 'react';
import { View, Text,Image, TextInput, Pressable,Switch} from 'react-native';
import {styles} from './styles';
import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      texto:'',
      nome: '',
      idade:0,
      valor:0,
      brasileiro: false,
      status:'Falso',
      sexoi:0,
      sexo: [{texto: 'Masculino'},
      {texto: 'Feminino'},
      {texto: 'Outros'},
    ]

    };
    
    this.confirmar = this.confirmar.bind(this);
  }


  confirmar(){
    if (this.state.nome === ''||this.state.idade === ''){
      alert('Digite os valores!')
      return;
    }
     else{
       if(this.state.brasileiro == false){
         this.setState({status:"Verdadeiro"})
       }else{
         this.setState({status:"Falso"})
      }
      this.setState({texto:'Dados pessoais:\n'+
        'Nome:'+this.state.nome+
        '\nIdade:'+this.state.idade+
        '\nSexo:'+ this.state.sexo[this.state.sexoi].texto+
        '\nLimite:R$'+this.state.valor+
        '\nBrasileiro:'+this.state.status});             
     } 

    
  }


  render(){
   let sexoItem = this.state.sexo.map( (valor, chave) => {
    return <Picker.Item key={chave} value={chave} label={valor.texto} />
  })

    return(
      <View>

      <Text style={styles.titulo}>Abertura de conta</Text>

      <Text style={styles.texto}>Nome:<TextInput
      style={styles.input}
      keyboardType='text'
      onChangeText={ (texto) => this.setState({nome: texto})}
      /></Text>

      <Text style={styles.texto}>Idade:
      <TextInput
      style={styles.input}
      keyboardType='numeric'
      onChangeText={ (texto) => this.setState({idade: texto})}
      /></Text>

      <Text style={styles.texto}>Sexo:
      <Picker
      selectedValue={this.state.sexoi}
      onValueChange={ (itemValue, itemIndex) => this.setState({sexoi: itemValue}) }
      >

      {sexoItem}


      </Picker>
      </Text>


 
      <Text style={styles.texto}>Limite: 
</Text><Slider
      minimumValue={0}
      maximumValue={1000}
      step={100}
      onValueChange={ (valorSelecionado) => this.setState({valor: valorSelecionado})}
      value={this.state.valor}    />
      <Text style={{textAlign: 'center', fontSize: 30}}>
      {this.state.valor.toFixed(0)}
    </Text>

    <Text style={styles.texto}>Brasileiro: <Switch 
      value={this.state.brasileiro}
      onValueChange={ (valorSwitch) => this.setState({brasileiro: valorSwitch})}
      />
</Text> 

      <Pressable style={styles.pressable}  onPress={this.confirmar}>
    <Text style={styles.texto}> Confirmar </Text>
    </Pressable>


      <Text style={styles.texto}>{this.state.texto} </Text>
      </View>
    );
  }
}



export default App;
