import React, { Component } from 'react';
import { View, Text,Image, TextInput, Pressable} from 'react-native';
import {styles} from './styles';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      resultado: '',
      alcool:0,
      gasolina:0
    };
    
    this.calcular = this.calcular.bind(this);
  }


  calcular(){
    if (this.state.alcool === ''||this.state.gasolina === ''){
      alert('Digite os valores!')
      return;
    }
    calculo= parseFloat(this.state.alcool) / parseFloat(this.state.gasolina);
    if(calculo<0.7){
    this.setState({resultado: 'Resultado: Alcool é melhor'});
    }else{
    this.setState({resultado: 'Resultado: Gasolina é melhor'});
    }
    
  }


  render(){

    let img = 'https://blog.autobitts.com.br/wp-content/uploads/2017/12/ab-bomba-de-gasolina.jpg';
    return(
      <View>

      <Text style={styles.titulo}>Alcool ou Gasolina</Text>
      <Image 
      source={{uri:img}}
      style={styles.img}
      />
      <TextInput
      style={styles.input}
      keyboardType='numeric'
      placeholder="Digite o preço do Alcool"
      onChangeText={ (texto) => this.setState({alcool: texto})}
      />
      
      <TextInput
      style={styles.input}
      placeholder="Digite o preço da Gasolina"
      keyboardType='numeric'
      onChangeText={ (texto) => this.setState({gasolina: texto})}
      />

      <Pressable style={styles.pressable}  onPress={this.calcular}>
    <Text style={styles.texto}> Verificar </Text>
    </Pressable>


      <Text style={styles.resultado}> {this.state.resultado} </Text>
      </View>
    );
  }
}



export default App;
