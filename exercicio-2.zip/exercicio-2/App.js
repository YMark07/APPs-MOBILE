import React, { Component } from 'react';
import { View, Text, Button, Pressable} from 'react-native';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      valor: 0
    };


    this.adc = this.adc.bind(this);
    this.sub = this.sub.bind(this);
  }
  
  adc(){
    this.setState({
      valor:  this.state.valor+1
    });
  }
    sub(){
    if(this.state.valor==0){

    }
    else{
    this.setState({
      valor: this.state.valor-1  
    });
    }
  }


  render(){
    return(
      <View style={{ marginTop: 20 }}>
        

        <Text style={{fontSize: 28,color: 'orange', textAlign: 'center',margin:10}}>
          Contador de pessoas:
        </Text>
        <Text style={{fontSize: 80, color: 'red', textAlign: 'center',margin:50,borderWidth: 4,}}>
          {this.state.valor}
        </Text>

        <Pressable style={{background:'green', width: 270,marginLeft:30,marginBottom:20, textAlign: 'center'}} title="+" onPress={this.adc}>
          <Text style={{fontSize: 50,color: 'white'}}>+</Text>
        </Pressable>
        <Pressable style={{background:'red', width: 270,marginLeft:30, textAlign: 'center'}} title="-" onPress={this.sub}>
          <Text style={{fontSize: 50,color: 'white'}}>-</Text>
        </Pressable>
      </View>
    )
  }
}


export default App;