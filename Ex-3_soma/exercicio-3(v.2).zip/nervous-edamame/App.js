import React, { Component } from 'react';
import { View, Text, StyleSheet, TextInput, Button} from 'react-native';
import {styles} from './styles';

class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      resultado: '',
      x:0,
      y:0
    };
    
    this.calcular = this.calcular.bind(this);
  }


  calcular(){
    if (this.state.x === ''||this.state.y === ''){
      alert('Digite os valores!')
      return;
    }
    soma= parseFloat(this.state.x) + parseFloat(this.state.y);
    this.setState({resultado: 'Resultado: '+ soma});
  }


  render(){
    return(
      <View style={styles.area}>


      <TextInput
      style={styles.input}
      placeholder="Digite o primeiro numero:"
      onChangeText={ (texto) => this.setState({x: texto})}
      />
      
      <TextInput
      style={styles.input}
      placeholder="Digite o segundo numero:"
      onChangeText={ (texto) => this.setState({y: texto})}
      />

      <Button title="Calcular" onPress={this.calcular} />


      <Text style={styles.texto}> {this.state.resultado} </Text>
      </View>
    );
  }
}



export default App;
