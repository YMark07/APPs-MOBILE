import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container:{
    flex: 1,
  },
    texto:{
    fontSize: 22,
  },
  titulo:{
  textAlign: 'center',
  fontSize: 25,
  margin: 35
  
  },
  pressable:{
    width: 250,
    height: 60,
    margin: 35,
    backgroundColor: 'green',
  }
},
)

export {styles}